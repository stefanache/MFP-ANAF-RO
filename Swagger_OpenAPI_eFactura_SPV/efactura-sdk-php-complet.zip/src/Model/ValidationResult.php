<?php
namespace Efatura\Model;

class ValidationResult {
    public $valid;
    public $errors = [];
}
