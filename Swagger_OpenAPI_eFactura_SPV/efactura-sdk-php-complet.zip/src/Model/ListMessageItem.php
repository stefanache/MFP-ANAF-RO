<?php
namespace Efatura\Model;

class ListMessageItem {
    public $messageId;
    public $status;
    public $data;
}
