<?php
namespace Efatura\Model;

class MessageStatus {
    public $messageId;
    public $status;
    public $details;
}
