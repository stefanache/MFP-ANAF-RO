<?php
namespace Efatura\Model;

class InvoiceUBL {
    private $xml;

    public function getXml() {
        return $this->xml;
    }

    public function setXml($xml) {
        $this->xml = $xml;
    }
}
